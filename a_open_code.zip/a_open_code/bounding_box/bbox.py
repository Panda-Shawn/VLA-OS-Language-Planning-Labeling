import os
import cv2
import torch
import json
import shutil
import numpy as np
from pathlib import Path
from tqdm import tqdm
from PIL import Image
import supervision as sv
from torchvision.ops import box_convert
from sam2.build_sam import build_sam2_video_predictor, build_sam2
from sam2.sam2_image_predictor import SAM2ImagePredictor
from grounding_dino.groundingdino.util.inference import load_model, load_image, predict
from utils.track_utils import sample_points_from_masks
from utils.video_utils import create_video_from_images

# ==== setting ====
GROUNDING_DINO_CONFIG = "grounding_dino/groundingdino/config/GroundingDINO_SwinT_OGC.py"
GROUNDING_DINO_CHECKPOINT = "gdino_checkpoints/groundingdino_swint_ogc.pth"
SAM2_CKPT = "./checkpoints/sam2.1_hiera_large.pt"
SAM2_CFG = "configs/sam2.1/sam2.1_hiera_l.yaml"
BOX_THRESHOLD = 0.25
TEXT_THRESHOLD = 0.25
TEXT_PROMPT = "bucket"  ################### The object name to be detected
PROMPT_TYPE_FOR_VIDEO = "mask"
SOURCE_VIDEO_FRAME_DIR = "./custom_video_frames_bucket"
REVERSED_FRAME_DIR = "./reversed_frames_bucket"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"



# ==== main function: process single video ====
def process_video(video_path, save_dir, output_video_path, grounding_model, video_predictor, image_predictor):
    ann_frame_idx = 0

    print(f"ann_frame_idx: {ann_frame_idx}")
   
    print(f"start processing: {video_path}, prompt frame index is {ann_frame_idx}")

    if os.path.exists(save_dir):
        shutil.rmtree(save_dir)
    os.makedirs(save_dir, exist_ok=True)

    # === Step 1: extract frames ===
    video_info = sv.VideoInfo.from_video_path(video_path)
    frame_generator = sv.get_video_frames_generator(video_path, stride=1, start=0, end=None)
    Path(SOURCE_VIDEO_FRAME_DIR).mkdir(parents=True, exist_ok=True)
    with sv.ImageSink(SOURCE_VIDEO_FRAME_DIR, overwrite=True, image_name_pattern="{:05d}.jpg") as sink:
        for frame in tqdm(frame_generator, desc=f"Extracting {Path(video_path).stem}"):
            sink.save_image(frame)
    frame_names = sorted([
        p for p in os.listdir(SOURCE_VIDEO_FRAME_DIR)
        if os.path.splitext(p)[-1].lower() in [".jpg", ".jpeg"]
    ], key=lambda p: int(os.path.splitext(p)[0]))

    inference_state = video_predictor.init_state(video_path=SOURCE_VIDEO_FRAME_DIR)
    img_path = os.path.join(SOURCE_VIDEO_FRAME_DIR, frame_names[ann_frame_idx])
    image_source, image = load_image(img_path)

    # === Step 2: prompt GroundingDINO to get box ===
    boxes, confidences, labels = predict(
        model=grounding_model, image=image, caption=TEXT_PROMPT,
        box_threshold=BOX_THRESHOLD, text_threshold=TEXT_THRESHOLD,
    )
    if boxes.size(0) == 0:
        raise ValueError("Grounding DINO did not detect any object.")
    # select the box with highest confidence for each label
    label_to_index = {}
    for i, label in enumerate(labels):
        score = confidences[i]
        if label not in label_to_index or score > confidences[label_to_index[label]]:
            label_to_index[label] = i
    keep_indices = list(label_to_index.values())
    boxes = boxes[keep_indices]
    confidences = confidences[keep_indices]
    labels = [labels[i] for i in keep_indices]

    h, w, _ = image_source.shape
    boxes = boxes * torch.Tensor([w, h, w, h])
    input_boxes = box_convert(boxes=boxes, in_fmt="cxcywh", out_fmt="xyxy").numpy()
    confidences = confidences.numpy().tolist()
    class_names = labels
    OBJECTS = class_names

    # === Step 3: use SAM2 to get mask and register objects ===
    image_predictor.set_image(image_source)
    masks, _, _ = image_predictor.predict(
        point_coords=None, point_labels=None, box=input_boxes,
        multimask_output=False,
    )
    if masks.ndim == 4:
        masks = masks.squeeze(1)

    for object_id, box in enumerate(input_boxes, start=1):
        video_predictor.add_new_points_or_box(
            inference_state, frame_idx=ann_frame_idx, obj_id=object_id, box=box)

    # === Step 4: forward propagation ===
    video_segments = {}
    for out_frame_idx, out_obj_ids, out_mask_logits in video_predictor.propagate_in_video(inference_state):
        video_segments[out_frame_idx] = {
            out_obj_id: (out_mask_logits[i] > 0.0).cpu().numpy()
            for i, out_obj_id in enumerate(out_obj_ids)
        }

    # === Step 5: backward propagation ===
    if os.path.exists(REVERSED_FRAME_DIR):
        shutil.rmtree(REVERSED_FRAME_DIR)
    Path(REVERSED_FRAME_DIR).mkdir(parents=True, exist_ok=True)
    for idx, fname in enumerate(reversed(frame_names)):
        src = os.path.join(SOURCE_VIDEO_FRAME_DIR, fname)
        dst = os.path.join(REVERSED_FRAME_DIR, f"{idx:05d}.jpg")
        shutil.copy(src, dst)
    inference_state_rev = video_predictor.init_state(video_path=REVERSED_FRAME_DIR)
    rev_idx = len(frame_names) - 1 - ann_frame_idx
    image_source_rev, _ = load_image(os.path.join(REVERSED_FRAME_DIR, f"{rev_idx:05d}.jpg"))
    image_predictor.set_image(image_source_rev)
    for object_id, box in enumerate(input_boxes, start=1):
        video_predictor.add_new_points_or_box(
            inference_state_rev, frame_idx=rev_idx, obj_id=object_id, box=box)
    for out_frame_idx, out_obj_ids, out_mask_logits in video_predictor.propagate_in_video(inference_state_rev):
        true_frame_idx = len(frame_names) - 1 - out_frame_idx
        if true_frame_idx not in video_segments:
            video_segments[true_frame_idx] = {
                out_obj_id: (out_mask_logits[i] > 0.0).cpu().numpy()
                for i, out_obj_id in enumerate(out_obj_ids)
            }

    # === Step 6: visualize + save mask + save JSON ===
    ID_TO_OBJECTS = {i: obj for i, obj in enumerate(OBJECTS, start=1)}
    all_frame_boxes = {}

    for frame_idx, segments in video_segments.items():
        if frame_idx < 0 or frame_idx >= len(frame_names):
            continue
        frame_name = frame_names[frame_idx]
        img = cv2.imread(os.path.join(SOURCE_VIDEO_FRAME_DIR, frame_name))
        object_ids = list(segments.keys())
        masks = list(segments.values())
        masks = np.concatenate(masks, axis=0)
        detections = sv.Detections(
            xyxy=sv.mask_to_xyxy(masks),
            mask=masks,
            class_id=np.array(object_ids, dtype=np.int32),
        )

        # save mask
        for i, obj_id in enumerate(object_ids):
            obj_name = ID_TO_OBJECTS[obj_id]
            mask_np = (detections.mask[i] * 255).astype(np.uint8)
            mask_dir = os.path.join(save_dir, obj_name)
            os.makedirs(mask_dir, exist_ok=True)
            mask_path = os.path.join(mask_dir, f"mask_{frame_name}")
            cv2.imwrite(mask_path, mask_np)

        # save box information
        frame_box_info = []
        for i, obj_id in enumerate(object_ids):
            xyxy = detections.xyxy[i].tolist()
            obj_name = ID_TO_OBJECTS[obj_id]
            frame_box_info.append([obj_name, xyxy])
        all_frame_boxes[frame_name] = frame_box_info

        # visualize
        box_annotator = sv.BoxAnnotator()
        mask_annotator = sv.MaskAnnotator()
        annotated_frame = box_annotator.annotate(scene=img.copy(), detections=detections)
        annotated_frame = mask_annotator.annotate(scene=annotated_frame, detections=detections)
        cv2.imwrite(os.path.join(save_dir, f"annotated_{frame_name}"), annotated_frame)

    with open(os.path.join(save_dir, "video_boxes.json"), "w") as f:
        json.dump(all_frame_boxes, f, indent=2)

    # output video
    create_video_from_images(save_dir, output_video_path)
    print(f"[done] {video_path} → {output_video_path}")


# ==== main entrance: batch process MP4 ====
if __name__ == "__main__":
    from pathlib import Path

    def get_video_list_from_dir(input_dir):
        """
        return the absolute path list of all .mp4 files in input_dir, sorted by name.
        """
        video_paths = sorted(Path(input_dir).glob("*.mp4"))
        return [str(p.resolve()) for p in video_paths]

    INPUT_DIR = "./dexart/bucket_png/bucket_viz"





    video_list = get_video_list_from_dir(INPUT_DIR)


    OUTPUT_BASE = "./dexart/results_bbox/vis_videos_bucket"
    if os.path.exists(OUTPUT_BASE):
        shutil.rmtree(OUTPUT_BASE)
    os.makedirs(OUTPUT_BASE)

    # === initialize models ===
    grounding_model = load_model(GROUNDING_DINO_CONFIG, GROUNDING_DINO_CHECKPOINT, device=DEVICE)
    video_predictor = build_sam2_video_predictor(SAM2_CFG, SAM2_CKPT)
    sam2_image_model = build_sam2(SAM2_CFG, SAM2_CKPT)
    image_predictor = SAM2ImagePredictor(sam2_image_model)

    # === batch process selected videos ===
    for video_path in video_list:
        name = Path(video_path).stem
        save_dir = os.path.join(OUTPUT_BASE, name)
        output_path = os.path.join(save_dir, "annotated_video.mp4")
        if os.path.exists(output_path):
            print(f"[skip] {name} already exists")
            continue
        print(f"[processing] {video_path}")
        process_video(video_path, save_dir, output_path, grounding_model, video_predictor, image_predictor)

