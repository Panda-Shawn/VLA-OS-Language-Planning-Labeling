#!/bin/bash

export GOOGLE_API_KEY=



python ./cot_code/batch_filter_plan_subtasks.py \
    --libero_dataset_dir ./results/toilet/filtered \
    --libero_primitives_path ./data/toilet/primitives.json \
    --libero_scene_desc_path ./data/toilet/descriptions_toilet_fixed.json \
    --libero_plan_subtasks_path ./results/toilet/cot/chain_of_thought_h10.json \
    --api_provider gemini
