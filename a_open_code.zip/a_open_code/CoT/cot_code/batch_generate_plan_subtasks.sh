#!/bin/bash

export GOOGLE_API_KEY=

python ./cot_code/batch_generate_plan_subtasks.py \
    --libero_dataset_dir ./results/toilet \
    --libero_primitives_path ./data/toilet/primitives.json \
    --libero_scene_desc_path ./data/toilet/descriptions_toilet_fixed.json \
    --batch_size 10 \
    --api_provider gemini
