
## bounding_box

1. Install the environment from [Grounded-SAM-2](https://github.com/IDEA-Research/Grounded-SAM-2).
2. Copy `bbox.py` to the `grounded_sam2` root directory (same location as the official main script).
3. Modify the `TEXT_PROMPT` variable in `bbox.py` to specify your target object.
4. Run `bbox.py` within the `grounded_sam2` environment.

### Manual Correction (Optional)

If the automatically annotated bounding boxes are not accurate:

1. Run `bounding_box/point_object_by_hand.py`.
2. Set the following parameters:
   - `ROOT_DIR`: directory containing extracted video frames.
   - `OUTPUT_FILE`: path to save the anchor CSV file.
3. Click the target object in each frame to annotate manually.
4. After all frames are annotated, a CSV file will be generated.

### Fix Bounding Boxes

1. Copy `bounding_box/bbox_fix_for_selected_eposide.py` into the `grounded_sam2` directory.
2. Set `ANCHOR_CSV` to the path of the generated CSV file.
3. Run `bbox_fix_for_selected_eposide.py` in the `grounded_sam2` environment.

### Post-processing

Run `bounding_box/post_process.ipynb` to extract bounding boxes into a JSON file.

---

## gripper_position

Run all cells in `gripper_position/gpos.ipynb` sequentially to obtain both simulation and real-world gripper position (`gpos`) data.

---

## move_primitives

Run all cells in `move_primitives/move_primitives.ipynb` in order to extract Move primitives from raw data.

---

## scense_description

1. Run `scense_description/generate_descriptions_dexart.py` to generate a description for each scene.
2. Run `scense_description/post_process.ipynb` to standardize the format of the descriptions.

---

## CoT

1. Run the following scripts in order:
   - `CoT/cot_code/batch_generate_plan_subtasks.sh`
   - `CoT/cot_code/batch_filter_plan_subtasks.sh`
2. This will generate the complete results.

---

## combine

1. Provide the previously generated files at the specified locations.
2. Run `combine/combine.py` to merge the outputs.
